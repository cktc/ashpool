import pytest
pytest.main()

# Dummy file to get pytest debugging working in VS Code